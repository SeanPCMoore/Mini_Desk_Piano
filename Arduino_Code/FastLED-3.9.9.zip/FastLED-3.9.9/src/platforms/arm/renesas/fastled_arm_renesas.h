#ifndef __INC_FASTLED_ARM_RENESAS_H
#define __INC_FASTLED_ARM_RENESAS_H

#include "fastpin_arm_renesas.h"
#include "../../fastspi_ardunio_core.h"
#include "clockless_arm_renesas.h"

#endif
