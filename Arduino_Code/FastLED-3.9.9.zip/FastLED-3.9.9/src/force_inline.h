#pragma once

#warning "This header is deprecated. Please use force_inline.h, this header will go away in the version 4.0."

#include "fl/force_inline.h"